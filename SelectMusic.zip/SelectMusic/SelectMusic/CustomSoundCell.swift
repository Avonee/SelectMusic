//
//  CustomSoundCell.swift
//  SelectMusic
//
//  Created by Ya Fang Cheng on 2016/11/4.
//  Copyright © 2016年 Ya Fang Cheng. All rights reserved.
//

import UIKit

class CustomSoundCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var checkmark: UIImageView!
    
    @IBOutlet weak var playSoundImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // checkMark.hidden = false
        // Configure the view for the selected state
    }
    
}
