//
//  ViewController.swift
//  SelectMusic
//
//  Created by Ya Fang Cheng on 2016/11/4.
//  Copyright © 2016年 Ya Fang Cheng. All rights reserved.
//



import UIKit
import MediaPlayer
import AVFoundation


class CustomSound: UITableViewController, AVAudioPlayerDelegate {
    
    
    
    var returnVC: UIViewController?
    
    let mediaItems = MPMediaQuery.songs().items
    var player: AVAudioPlayer?
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        
        
        let bgView = UIImageView(image: UIImage(named: "bk"))
        bgView.contentMode = .scaleAspectFill
        self.tableView.backgroundColor = UIColor.clear
        self.tableView.backgroundView = bgView
        
        // set navigation bar button item
        let backBtn = UIButton(type: .custom)
        backBtn.setBackgroundImage(UIImage(named: "ic_last"), for: .normal)
        backBtn.addTarget(self, action: #selector(exitButtonClick), for: .touchUpInside)
        backBtn.frame = CGRect(x:0, y:0, width:24, height:24)
//        backBtn.frame = CGRectMake(0, 0, 24, 24)
        let backButton = UIBarButtonItem(customView: backBtn)
        self.navigationItem.leftBarButtonItem = backButton
        
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
        
    }
    
    @IBAction func exitButtonClick(sender: UIBarButtonItem){
        
        if ((player?.play()) != nil){
            player!.pause()
        }
        navigationController?.popViewController(animated: true)
        
        
    }
    
    
    @IBAction func saveButtonClick(sender: UIBarButtonItem){
        
        player!.pause()
        
       
        
        
        
        navigationController?.popViewController(animated: true)
        
    }
    
    
    
    
    override func tableView( _ tableView: UITableView, numberOfRowsInSection section: Int ) -> Int  {
        
        print("有幾個自訂音效？\(mediaItems?.count)")
        
        return (mediaItems?.count)!
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath as IndexPath) as? CustomSoundCell
        
        
        
        
        
        cell?.nameLabel.text = "\(mediaItems![indexPath.row].title!)"
        
        
        cell?.checkmark.isHidden = true
        return cell!
    }
    
    // MARK: tableView delegate
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath as IndexPath) as! CustomSoundCell
        cell.checkmark.isHidden = false
        
        
        
        let songId = Int(MPMediaQuery.songs().items![indexPath.row].persistentID)
        //        functionParameter.soundBySelfID = songId
        let item: MPMediaItem = self.getItem( songId: songId )
        
        let url: NSURL = item.value( forProperty: MPMediaItemPropertyAssetURL ) as! NSURL
        //        functionParameter.soundBySelf = MPMediaQuery.songsQuery().items![indexPath.row].title!
        
        
        try! AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
        try! AVAudioSession.sharedInstance().setActive(true)
        
        try! player = AVAudioPlayer(contentsOf: url as URL)
        if let player = player{
            player.delegate = self
            player.volume = 1.0
            player.prepareToPlay()
            player.play()
            
        }
    }
    
    
    
    
    func getItem( songId: Int ) -> MPMediaItem {
        
        let property: MPMediaPropertyPredicate = MPMediaPropertyPredicate( value: songId, forProperty: MPMediaItemPropertyPersistentID )
        
        let query: MPMediaQuery = MPMediaQuery()
        query.addFilterPredicate( property )
        
        var items: [MPMediaItem] = query.items! as [MPMediaItem]
        
        return items[items.count - 1]
        
    }
    
    override func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath as IndexPath) as! CustomSoundCell
        
        cell.checkmark.isHidden = true
    }
    
    
    // MARK: AVAudioPlayer Delegate
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        try! AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryAmbient)
    }
    
    
    
   
    
}


