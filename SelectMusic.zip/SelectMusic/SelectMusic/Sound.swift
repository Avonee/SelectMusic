//
//  Sound.swift
//  SelectMusic
//
//  Created by Ya Fang Cheng on 2016/11/4.
//  Copyright © 2016年 Ya Fang Cheng. All rights reserved.
//

import UIKit
import MediaPlayer

class Sound: UIViewController {

    @IBOutlet weak var customSoundName: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        
      
        
        
//        if functionalParameter.soundBySelf != nil{
//            
//            self.customSoundName.titleLabel?.text = "\(functionalParameter.soundBySelf!)"
//            self.customSoundName.setTitle("\(functionalParameter.soundBySelf!)", forState: .Normal)
//        }
    }

    //custom Sound Click
    
//    @IBAction func customSoundClick(sender: AnyObject) {
//        
//       
//        
//       
//        
//        if #available(iOS 9.3, *) {
//            MPMediaLibrary.requestAuthorization { (status) in
//                if status == .authorized {
//                    self.performSegue(withIdentifier: "to_CustomSound", sender: self)
//                } else {
//                    return
//                }
//            }
//        } else {
//            // Fallback on earlier versions
//            self.performSegue(withIdentifier: "to_CustomSound", sender: self)
//        }
//    }
//    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "to_CustomSound"{
//            _ = segue.destination as! CustomSound
//            
//        }
//    }
    
    
    

}
